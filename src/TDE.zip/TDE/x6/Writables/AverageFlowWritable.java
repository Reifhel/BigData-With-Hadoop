package TDE.x6.Writables;

public class AverageFlowWritable {
    
}
